"""
operators.py — Blender operator classes for Godot Bridge.
"""

import os
import bpy
import mathutils
from bpy.props import BoolProperty, IntProperty, StringProperty
from bpy.types import Operator

from .utils import (
    abs_dir, sanitize, validate_paths, validate_paths_no_scenes,
)
from .export_tscn import build_tscn, build_single_object_tscn


# ---------------------------------------------------------------------------
# Fix 1: membership helpers  (replaces all comma-string access)
# ---------------------------------------------------------------------------

def get_membership_names(obj):
    """Return list of scene name strings this object belongs to."""
    props = obj.godot_props
    # Migrate legacy comma-string on first access
    if props.scene_memberships.strip() and len(props.memberships) == 0:
        for part in props.scene_memberships.split(","):
            name = part.strip()
            if name:
                entry = props.memberships.add()
                entry.scene_name = name
        props.scene_memberships = ""   # clear legacy field
    return [e.scene_name for e in props.memberships]


def set_membership_names(obj, names):
    """Overwrite the object's membership list with the given names."""
    props = obj.godot_props
    props.memberships.clear()
    for name in names:
        e = props.memberships.add()
        e.scene_name = name


def obj_is_member(obj, scene_name):
    names = get_membership_names(obj)
    return not names or scene_name in names   # empty = all scenes


def add_membership(obj, scene_name):
    names = get_membership_names(obj)
    if scene_name not in names:
        names.append(scene_name)
    set_membership_names(obj, names)


def remove_membership(obj, scene_name):
    names = [n for n in get_membership_names(obj) if n != scene_name]
    set_membership_names(obj, names)


# ---------------------------------------------------------------------------
# Fix 6: bulk-apply operator with UNDO and confirmation for large selections
# ---------------------------------------------------------------------------

class GODOT_OT_ApplyToSelected(Operator):
    bl_idname  = "godot_bridge.apply_to_selected"
    bl_label   = "Apply Settings to All Selected"
    bl_description = (
        "Copy the active object's Export, Node Type, GLB Export, "
        "Body Type, and Collision settings to all other selected objects. "
        "Node Name and Parent Node are NOT copied (must be unique per object)."
    )
    bl_options = {'REGISTER', 'UNDO'}

    confirmed: BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        targets = [o for o in context.selected_objects if o != context.active_object]
        if len(targets) > 10 and not self.confirmed:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        active = context.active_object
        if not active:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        src     = active.godot_props
        targets = [o for o in context.selected_objects if o != active]
        if not targets:
            self.report({'WARNING'}, "No other objects selected.")
            return {'CANCELLED'}
        for obj in targets:
            dst = obj.godot_props
            dst.export                   = src.export
            dst.godot_node_type          = src.godot_node_type
            dst.glb_export_mode          = src.glb_export_mode
            dst.glb_group_name           = src.glb_group_name
            dst.body_type                = src.body_type
            dst.add_collision            = src.add_collision
            dst.auto_collision_type      = src.auto_collision_type
            dst.custom_collision_subtype = src.custom_collision_subtype
            dst.collision_shape          = src.collision_shape
        self.report({'INFO'}, f"Applied to {len(targets)} object(s).")
        return {'FINISHED'}


class GODOT_OT_DetectProjectRoot(Operator):
    bl_idname  = "godot_bridge.detect_project_root"
    bl_label   = "Auto-detect Root from Export Folder"
    bl_description = "Walk up from the Export Folder looking for project.godot"

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.export_path.strip():
            self.report({'WARNING'}, "Set Export Folder first.")
            return {'CANCELLED'}
        path = abs_dir(sp.export_path)
        for _ in range(20):
            if os.path.isfile(os.path.join(path, "project.godot")):
                sp.project_root = path + os.sep
                self.report({'INFO'}, f"Found: {path}")
                return {'FINISHED'}
            parent = os.path.dirname(path)
            if parent == path:
                break
            path = parent
        self.report({'WARNING'}, "Could not find project.godot. Set manually.")
        return {'CANCELLED'}


class GODOT_OT_ExportScene(Operator):
    bl_idname  = "godot_bridge.export_scene"
    bl_label   = "Export All Scenes"
    bl_description = "Export all scene definitions to .tscn + GLB files"

    def execute(self, context):
        sp  = context.scene.godot_scene_props
        err = validate_paths(context)
        if err:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        project_root_abs = abs_dir(sp.project_root)
        export_dir_abs   = abs_dir(sp.export_path)
        os.makedirs(export_dir_abs, exist_ok=True)

        exported = []
        errors   = []
        for scene_def in sp.scenes:
            sname = scene_def.scene_name.strip() or "scene"
            try:
                tscn_content = build_tscn(context, project_root_abs,
                                          export_dir_abs, scene_def)
            except Exception as e:
                errors.append(f"{sname}: {e}")
                import traceback; traceback.print_exc()
                continue
            tscn_path = os.path.join(export_dir_abs, sname + ".tscn")
            with open(tscn_path, 'w', encoding='utf-8') as f:
                f.write(tscn_content)
            exported.append(sname)

        if exported:
            self.report({'INFO'}, f"Exported: {', '.join(exported)}")
        if errors:
            self.report({'ERROR'}, "Errors: " + "; ".join(errors))
        return {'FINISHED'} if exported else {'CANCELLED'}


class GODOT_OT_ExportActiveScene(Operator):
    bl_idname  = "godot_bridge.export_active_scene"
    bl_label   = "Export This Scene"
    bl_description = "Export only the currently selected scene definition"

    def execute(self, context):
        sp  = context.scene.godot_scene_props
        err = validate_paths(context)
        if err:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        if not sp.scenes or sp.active_scene_index >= len(sp.scenes):
            self.report({'ERROR'}, "No scene selected.")
            return {'CANCELLED'}
        scene_def        = sp.scenes[sp.active_scene_index]
        project_root_abs = abs_dir(sp.project_root)
        export_dir_abs   = abs_dir(sp.export_path)
        os.makedirs(export_dir_abs, exist_ok=True)
        sname = scene_def.scene_name.strip() or "scene"
        try:
            tscn_content = build_tscn(context, project_root_abs,
                                      export_dir_abs, scene_def)
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            import traceback; traceback.print_exc()
            return {'CANCELLED'}
        tscn_path = os.path.join(export_dir_abs, sname + ".tscn")
        with open(tscn_path, 'w', encoding='utf-8') as f:
            f.write(tscn_content)
        self.report({'INFO'}, f"Exported: {tscn_path}")
        return {'FINISHED'}


class GODOT_OT_AddScene(Operator):
    bl_idname  = "godot_bridge.add_scene"
    bl_label   = "Add Scene"
    bl_description = "Add a new scene definition"

    def execute(self, context):
        sp  = context.scene.godot_scene_props
        new = sp.scenes.add()
        existing = {s.scene_name for s in sp.scenes}
        base = "scene"
        name = base
        i = 1
        while name in existing:
            name = f"{base}_{i}"; i += 1
        new.scene_name = name
        new.prev_name  = name   # Fix 1: seed the rename tracker
        sp.active_scene_index = len(sp.scenes) - 1
        return {'FINISHED'}


class GODOT_OT_RemoveScene(Operator):
    bl_idname  = "godot_bridge.remove_scene"
    bl_label   = "Remove Scene"
    bl_description = "Remove the selected scene definition"

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.scenes:
            return {'CANCELLED'}
        sp.scenes.remove(sp.active_scene_index)
        sp.active_scene_index = max(0, sp.active_scene_index - 1)
        return {'FINISHED'}


class GODOT_OT_AssignToScene(Operator):
    """Add or remove the active scene name from selected objects' memberships."""
    bl_idname  = "godot_bridge.assign_to_scene"
    bl_label   = "Assign/Remove Selected from Scene"
    bl_options = {'REGISTER', 'UNDO'}

    assign: BoolProperty(default=True)

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.scenes or sp.active_scene_index >= len(sp.scenes):
            self.report({'WARNING'}, "No scene selected.")
            return {'CANCELLED'}
        scene_def = sp.scenes[sp.active_scene_index]
        sname = scene_def.scene_name.strip()
        if not sname:
            return {'CANCELLED'}
        changed = 0
        for obj in context.selected_objects:
            p = obj.godot_props
            if self.assign:
                already_member = sname in get_membership_names(obj)
                add_membership(obj, sname)
                p.export = True
                # Only apply scene defaults the FIRST time an object is assigned.
                # If the object is already a member, preserve any per-object
                # overrides the user has made (fixes Bug 1: collision type reset).
                if (not scene_def.use_object_settings
                        and not already_member
                        and obj.type == 'MESH'
                        and p.godot_node_type == "MeshInstance3D"):
                    p.body_type           = scene_def.default_body_type
                    p.add_collision       = scene_def.default_add_collision
                    p.auto_collision_type = scene_def.default_collision_type
            else:
                before = len(get_membership_names(obj))
                remove_membership(obj, sname)
                if len(get_membership_names(obj)) != before:
                    changed += 1
                continue
            changed += 1
        verb = "Added" if self.assign else "Removed"
        self.report({'INFO'},
            f"{verb} {changed} selected object(s) {'to' if self.assign else 'from'} '{sname}'.")
        return {'FINISHED'}


class GODOT_OT_MarkSelected(Operator):
    bl_idname = "godot_bridge.mark_selected"
    bl_label  = "Mark/Unmark Selected"
    bl_options = {'REGISTER', 'UNDO'}
    mark: BoolProperty(default=True)

    def execute(self, context):
        for obj in context.selected_objects:
            obj.godot_props.export = self.mark
        return {'FINISHED'}


# Fix 8: remove a single scene membership from the Object Panel
class GODOT_OT_RemoveMembership(Operator):
    """Remove one scene from this object's membership list."""
    bl_idname  = "godot_bridge.remove_membership"
    bl_label   = "Remove Scene Membership"
    bl_description = "Remove this scene from the object's membership list"
    bl_options = {'REGISTER', 'UNDO'}

    scene_name: StringProperty(default="")

    def execute(self, context):
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}
        remove_membership(obj, self.scene_name)
        return {'FINISHED'}


class GODOT_OT_AddCollection(Operator):
    bl_idname  = "godot_bridge.add_collection"
    bl_label   = "Add Collection"
    bl_description = "Add a collection to this scene's Collection Mode list"

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.scenes or sp.active_scene_index >= len(sp.scenes):
            return {'CANCELLED'}
        sd  = sp.scenes[sp.active_scene_index]
        new = sd.collections.add()
        new.collection_name = ""
        sd.active_collection_index = len(sd.collections) - 1
        return {'FINISHED'}


class GODOT_OT_RemoveCollection(Operator):
    bl_idname  = "godot_bridge.remove_collection"
    bl_label   = "Remove Collection"
    bl_description = "Remove the selected collection from this scene's list"

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.scenes or sp.active_scene_index >= len(sp.scenes):
            return {'CANCELLED'}
        sd = sp.scenes[sp.active_scene_index]
        if not sd.collections:
            return {'CANCELLED'}
        sd.collections.remove(sd.active_collection_index)
        sd.active_collection_index = max(0, sd.active_collection_index - 1)
        return {'FINISHED'}


class GODOT_OT_PickCollection(Operator):
    """Legacy shim — collection_picker now has an update callback so this is
    no longer needed in normal flow, but kept so saved .blend files that
    reference the operator don't break on load."""
    bl_idname  = "godot_bridge.pick_collection"
    bl_label   = "Apply Collection Pick"
    bl_description = "Set collection name from the dropdown selection"

    scene_index:      IntProperty(default=0)
    collection_index: IntProperty(default=0)

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if self.scene_index >= len(sp.scenes):
            return {'CANCELLED'}
        sd = sp.scenes[self.scene_index]
        if self.collection_index >= len(sd.collections):
            return {'CANCELLED'}
        cd = sd.collections[self.collection_index]
        picked = cd.collection_picker
        if picked and picked in bpy.data.collections:
            cd.collection_name = picked
        return {'FINISHED'}


class GODOT_OT_AddCollisionProxy(Operator):
    bl_idname  = "godot_bridge.add_collision_proxy"
    bl_label   = "Add Collision Proxy Mesh"
    bl_description = (
        "Create a box mesh scaled to this collection's bounding box and "
        "assign it as the combined collision proxy"
    )
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(default="")

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.scenes or sp.active_scene_index >= len(sp.scenes):
            return {'CANCELLED'}
        sd    = sp.scenes[sp.active_scene_index]
        cname = self.collection_name.strip()
        if not cname:
            self.report({'WARNING'}, "No collection name set.")
            return {'CANCELLED'}

        bl_col = bpy.data.collections.get(cname)
        if bl_col is None:
            self.report({'WARNING'}, f"Collection '{cname}' not found.")
            return {'CANCELLED'}

        cd = next((c for c in sd.collections if c.collection_name == cname), None)
        if cd is None:
            self.report({'WARNING'}, "Collection def not found.")
            return {'CANCELLED'}

        mesh_objs = [o for o in bl_col.objects if o.type == 'MESH'
                     and not o.godot_props.is_collision_proxy]
        if not mesh_objs:
            self.report({'WARNING'}, "No mesh objects in this collection.")
            return {'CANCELLED'}

        import bmesh as _bm
        all_pts = []
        for obj in mesh_objs:
            mw = obj.matrix_world
            for corner in obj.bound_box:
                all_pts.append(mw @ mathutils.Vector(corner))

        xs = [p.x for p in all_pts]
        ys = [p.y for p in all_pts]
        zs = [p.z for p in all_pts]
        cx = (max(xs) + min(xs)) * 0.5
        cy = (max(ys) + min(ys)) * 0.5
        cz = (max(zs) + min(zs)) * 0.5
        sx = (max(xs) - min(xs)) * 0.5
        sy = (max(ys) - min(ys)) * 0.5
        sz = (max(zs) - min(zs)) * 0.5

        proxy_name = f"_proxy_{sanitize(cname)}"
        if proxy_name in bpy.data.objects:
            bpy.data.objects.remove(bpy.data.objects[proxy_name], do_unlink=True)

        mesh_data  = bpy.data.meshes.new(proxy_name)
        proxy_obj  = bpy.data.objects.new(proxy_name, mesh_data)

        bm = _bm.new()
        _bm.ops.create_cube(bm, size=2.0)
        bm.to_mesh(mesh_data)
        bm.free()

        proxy_obj.location = (cx, cy, cz)
        proxy_obj.scale    = (sx, sy, sz)
        proxy_obj.display_type = 'WIRE'
        proxy_obj.godot_props.is_collision_proxy = True

        bl_col.objects.link(proxy_obj)
        if proxy_obj.name not in context.scene.collection.objects:
            context.scene.collection.objects.link(proxy_obj)

        cd.collision_proxy = proxy_obj
        self.report({'INFO'}, f"Created proxy: {proxy_name}")
        return {'FINISHED'}


class GODOT_OT_SwitchToBatchExport(Operator):
    """Switch the N-panel to the Batch Object Export panel."""
    bl_idname  = "godot_bridge.switch_to_batch"
    bl_label   = "Switch to Batch Export"
    bl_description = (
        "Open the Batch Object Export panel — export each object as its own .tscn file "
        "(asset library workflow)"
    )

    def execute(self, context):
        # Find the Godot Export category in the sidebar and make Batch panel visible.
        # The simplest cross-version approach: just report a hint — the user clicks
        # the Batch tab.  We also set a scene flag so the Scene panel can show a
        # contextual call-to-action pointing there.
        context.scene.godot_scene_props.hint_switch_to_batch = True
        self.report({'INFO'}, "Switch to the 'Batch' tab in the Godot Export sidebar.")
        return {'FINISHED'}


class GODOT_OT_SelectSceneObjects(Operator):
    bl_idname  = "godot_bridge.select_scene_objects"
    bl_label   = "Select Scene Objects"
    bl_description = "Select all objects assigned to the active scene in the viewport"

    def execute(self, context):
        sp = context.scene.godot_scene_props
        if not sp.scenes or sp.active_scene_index >= len(sp.scenes):
            self.report({'WARNING'}, "No scene selected.")
            return {'CANCELLED'}
        sname = sp.scenes[sp.active_scene_index].scene_name.strip()
        bpy.ops.object.select_all(action='DESELECT')
        count = 0
        for obj in context.scene.objects:
            if not obj.godot_props.export:
                continue
            names = get_membership_names(obj)
            if not names or sname in names:
                obj.select_set(True)
                count += 1
        self.report({'INFO'}, f"Selected {count} object(s) in scene '{sname}'.")
        return {'FINISHED'}


class GODOT_OT_BatchExportObjects(Operator):
    bl_idname  = "godot_bridge.batch_export_objects"
    bl_label   = "Batch Export Objects"
    bl_description = (
        "Export each marked mesh object as its own individual .tscn + GLB file. "
        "Uses the Root Node, Body, and Collision settings in the Batch Export panel "
        "unless 'Use Per-Object Settings' is enabled."
    )

    def execute(self, context):
        sp  = context.scene.godot_scene_props
        err = validate_paths_no_scenes(context)
        if err:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}

        project_root_abs = abs_dir(sp.project_root)
        export_dir_abs   = abs_dir(sp.export_path)
        os.makedirs(export_dir_abs, exist_ok=True)

        if sp.batch_only_selected:
            candidates = [o for o in context.selected_objects if o.type == 'MESH']
        else:
            candidates = [
                o for o in context.scene.objects
                if o.type == 'MESH'
                and o.godot_props.export
                and not o.godot_props.is_collision_proxy
                and o.godot_props.godot_node_type != "NONE"
            ]

        if not candidates:
            self.report({'WARNING'}, "No mesh objects found to batch export.")
            return {'CANCELLED'}

        exported = []
        errors   = []

        for obj in candidates:
            # Fix 10: honour per-object settings when the toggle is on
            if sp.batch_use_per_object_settings:
                p = obj.godot_props
                root_node_type = "Node3D"
                body_type      = p.body_type
                add_collision  = p.add_collision
                collision_type = p.auto_collision_type
            else:
                root_node_type = sp.batch_root_node_type
                body_type      = sp.batch_body_type
                add_collision  = sp.batch_add_collision
                collision_type = sp.batch_collision_type

            try:
                tscn_content = build_single_object_tscn(
                    context,
                    project_root_abs,
                    export_dir_abs,
                    obj,
                    root_node_type = root_node_type,
                    body_type      = body_type,
                    add_collision  = add_collision,
                    collision_type = collision_type,
                )
            except Exception as e:
                errors.append(f"{obj.name}: {e}")
                import traceback; traceback.print_exc()
                continue

            tscn_path = os.path.join(export_dir_abs, sanitize(obj.name) + ".tscn")
            with open(tscn_path, 'w', encoding='utf-8') as f:
                f.write(tscn_content)
            exported.append(obj.name)

        if exported:
            self.report({'INFO'}, f"Batch exported {len(exported)} object(s): {', '.join(exported)}")
        if errors:
            self.report({'ERROR'}, "Errors: " + "; ".join(errors))
        return {'FINISHED'} if exported else {'CANCELLED'}
