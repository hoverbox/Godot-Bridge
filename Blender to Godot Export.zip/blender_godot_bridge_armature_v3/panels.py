"""
panels.py — Blender UI panels for Blender to Godot Export.
"""

import bpy
from bpy.types import Panel

from .utils import (
    sanitize, compute_res_path, abs_dir,
    PRIMITIVE_SHAPES, MESH_SHAPES,
    validate_paths, validate_paths_no_scenes,
    SCENE_EXPORT_MODES,
)
from .operators import get_membership_names


# ---------------------------------------------------------------------------
# Fix 5: Setup checklist helper
# ---------------------------------------------------------------------------

def _setup_steps(context):
    """
    Return a list of (done: bool, label: str) tuples for the onboarding
    checklist.  Returns None when all steps are complete.
    """
    sp = context.scene.godot_scene_props
    steps = []

    # Step 1 — export folder
    exp_ok = bool(sp.export_path.strip())
    steps.append((exp_ok, "① Set Export Folder"))

    # Step 2 — project root with project.godot
    import os
    proj_ok = False
    if sp.project_root.strip():
        proj_abs = abs_dir(sp.project_root)
        proj_ok = os.path.isfile(os.path.join(proj_abs, "project.godot"))
    steps.append((proj_ok, "② Set (or Auto-detect) Project Root"))

    # Step 3 — at least one scene
    scene_ok = len(sp.scenes) > 0
    steps.append((scene_ok, "③ Add at least one Scene"))

    all_done = all(done for done, _ in steps)
    return None if all_done else steps


# ---------------------------------------------------------------------------
# Fix 3: shared collision drawing helper
# ---------------------------------------------------------------------------

def _draw_collision_section(layout, props, obj, prop_name, context_label=""):
    """
    Unified collision section.  `prop_name` is the property to read/write
    (auto_collision_type for MeshInstance3D, collision_shape for standalone
    CollisionShape3D nodes).
    """
    if context_label:
        layout.label(text=context_label, icon='MESH_ICOSPHERE')

    layout.prop(props, prop_name, text="Shape")
    ctype = getattr(props, prop_name)

    layout.prop(props, "collision_custom_mesh", text="Custom Mesh (optional)")
    has_custom = props.collision_custom_mesh is not None

    try:
        from .export_glb import object_has_armature
        is_rigged = object_has_armature(obj)
    except Exception:
        is_rigged = False
    if is_rigged and ctype in {"CONVEX", "CONCAVE", "CUSTOM"}:
        layout.label(text="Rigged mesh: prefer capsule/box proxy collision.", icon='ERROR')

    if ctype in PRIMITIVE_SHAPES:
        if has_custom:
            layout.label(text="Primitive ignores custom mesh — uses bbox.", icon='INFO')
        elif obj.type == 'MESH':
            layout.label(text="Auto-sized from bounding box.", icon='INFO')
        else:
            layout.label(text="No mesh — 0.5 m default size.", icon='ERROR')

    elif ctype == "CONVEX":
        if has_custom:
            layout.label(text=f"Source: {props.collision_custom_mesh.name}", icon='INFO')
        elif obj.type != 'MESH':
            layout.label(text="Object must be a mesh for Convex.", icon='ERROR')
        else:
            layout.label(text="ConvexPolygonShape3D from this mesh.", icon='INFO')

    elif ctype == "CONCAVE":
        if has_custom:
            layout.label(text=f"Source: {props.collision_custom_mesh.name}", icon='INFO')
        elif obj.type != 'MESH':
            layout.label(text="Object must be a mesh for Concave.", icon='ERROR')
        else:
            layout.label(text="ConcavePolygonShape3D — static bodies only!", icon='INFO')

    elif ctype == "CUSTOM":
        layout.prop(props, "custom_collision_subtype", text="Shape Type")
        if not props.collision_custom_mesh:
            layout.label(text="No mesh selected — will use this object.", icon='ERROR')
        else:
            layout.label(text=f"Source: {props.collision_custom_mesh.name}", icon='INFO')


# ---------------------------------------------------------------------------
# Fix 5: Project panel with onboarding checklist
# ---------------------------------------------------------------------------

class GODOT_PT_ProjectPanel(Panel):
    """Top-level panel for Godot project path settings."""
    bl_label       = "Godot Project"
    bl_idname      = "GODOT_PT_project_panel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Godot Export"
    bl_order       = 0

    def draw(self, context):
        layout = self.layout
        sp     = context.scene.godot_scene_props

        # Fix 5: show setup checklist until all three steps are done
        steps = _setup_steps(context)
        if steps:
            setup_box = layout.box()
            setup_box.label(text="Getting Started", icon='INFO')
            for done, label in steps:
                row = setup_box.row()
                row.label(
                    text=label,
                    icon='CHECKMARK' if done else 'RADIOBUT_OFF',
                )
            layout.separator()

        box = layout.box()
        box.prop(sp, "export_path",  text="Export Folder")
        box.prop(sp, "project_root", text="Project Root")
        box.operator("godot_bridge.detect_project_root",
                     text="Auto-detect Root from Export Folder", icon='VIEWZOOM')
        if sp.export_path.strip() and sp.project_root.strip():
            try:
                sample = compute_res_path(
                    abs_dir(sp.project_root), abs_dir(sp.export_path), "example.glb"
                )
                box.label(text=f"→ {sample}", icon='INFO')
            except Exception:
                pass

        # Fix 9: reworded apply_transforms with consequence warning
        box.prop(sp, "apply_transforms")
        if sp.apply_transforms:
            box.label(text="Rigged/skinned meshes automatically export without baking.", icon='INFO')
        else:
            box.label(text="⚠ OFF: object may be placed at origin in Godot.", icon='ERROR')
        box.label(text="Materials are embedded in exported .glb files", icon='MATERIAL')


# ---------------------------------------------------------------------------
# Fix 4 & 3 & 8: Object panel — context-aware layout + inline membership removal
# ---------------------------------------------------------------------------

class GODOT_PT_ObjectPanel(Panel):
    bl_label       = "Godot Object Settings"
    bl_idname      = "GODOT_PT_object_panel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Godot Export"
    bl_order       = 1

    def draw(self, context):
        layout = self.layout
        obj    = context.active_object

        if obj is None:
            layout.label(text="No active object", icon='INFO')
            return

        props = obj.godot_props
        box   = layout.box()
        box.label(text=obj.name, icon='OBJECT_DATA')
        box.prop(props, "export", text="Export this object")

        if not props.export:
            return

        box.prop(props, "godot_node_type")

        # Fix 4: only show sections relevant to the current node type
        ntype = props.godot_node_type

        if ntype == "NONE":
            box.label(text="Object will be skipped during export.", icon='INFO')
            return

        box.prop(props, "node_name",   text="Override Name")
        box.prop(props, "parent_node", text="Parent Node")

        # ── MeshInstance3D ──────────────────────────────────────────────────
        if obj.type == 'MESH' and ntype == "MeshInstance3D":
            mesh_box = layout.box()
            mesh_box.label(text="Mesh / GLB Export", icon='MESH_DATA')
            mesh_box.prop(props, "glb_export_mode")
            if props.glb_export_mode == "GROUP":
                mesh_box.prop(props, "glb_group_name")

            body_box = layout.box()
            body_box.label(text="Physics Body", icon='PHYSICS')
            body_box.prop(props, "body_type")

            col_box = layout.box()
            col_box.prop(props, "add_collision", text="Add Collision Shape")
            if props.add_collision:
                # Fix 3: unified collision helper with clear context label
                _draw_collision_section(
                    col_box, props, obj, "auto_collision_type",
                    context_label="Collision for this Mesh",
                )

        # ── Standalone CollisionShape3D ─────────────────────────────────────
        elif ntype == "CollisionShape3D":
            col_box = layout.box()
            # Fix 3: unified helper, clearly labelled
            _draw_collision_section(
                col_box, props, obj, "collision_shape",
                context_label="Standalone Collision Shape",
            )

        # ── Physics body node types (no mesh) ───────────────────────────────
        elif ntype in {"StaticBody3D", "RigidBody3D", "CharacterBody3D",
                       "AnimatableBody3D", "Area3D", "VehicleBody3D"}:
            body_box = layout.box()
            body_box.label(text="Physics Body Node", icon='PHYSICS')
            body_box.label(text=f"Will export as {ntype}.", icon='INFO')

        # ── Collection mode primary collection ──────────────────────────────
        sp = context.scene.godot_scene_props
        if sp.scenes:
            coll_box = layout.box()
            coll_box.label(text="Collection Mode", icon='OUTLINER_COLLECTION')
            coll_box.prop(props, "primary_collection", text="Primary Collection")
            if props.is_collision_proxy:
                coll_box.label(text="⚠ This is a collision proxy mesh", icon='ERROR')

        # ── Fix 8: Scene membership summary with inline × buttons ───────────
        if sp.scenes:
            member_box = layout.box()
            member_box.label(text="Scene Memberships", icon='SCENE_DATA')
            names = get_membership_names(obj)

            # Fix 1: validate names against current scene list; warn on stale
            current_scene_names = {s.scene_name.strip() for s in sp.scenes}
            stale = [n for n in names if n not in current_scene_names]
            if stale:
                member_box.label(
                    text=f"⚠ Unknown scene(s): {', '.join(stale)}",
                    icon='ERROR',
                )

            if not names:
                member_box.label(text="(all scenes — no filter set)", icon='INFO')
            else:
                for sname in names:
                    row = member_box.row(align=True)
                    row.label(
                        text=sname,
                        icon='SCENE' if sname in current_scene_names else 'ERROR',
                    )
                    # Fix 8: inline × removal button
                    op = row.operator("godot_bridge.remove_membership",
                                      text="", icon='X')
                    op.scene_name = sname

        # ── Bulk actions ──────────────────────────────────────────────────
        layout.separator()
        sel_count = len(context.selected_objects)
        row = layout.row(align=True)
        op  = row.operator("godot_bridge.mark_selected", text="Copy From Selected", icon='COPYDOWN')
        op.mark = True
        op2 = row.operator("godot_bridge.mark_selected", text="Remove Settings", icon='X')
        op2.mark = False

        if sel_count > 1:
            layout.operator(
                "godot_bridge.apply_to_selected",
                text=f"Apply Settings to {sel_count - 1} Other Selected",
                icon='COPYDOWN',
            )
        else:
            r = layout.row()
            r.enabled = False
            r.label(text="Select multiple objects to bulk-apply", icon='INFO')


# ---------------------------------------------------------------------------
# Scene list UIList
# ---------------------------------------------------------------------------

class GODOT_UL_SceneList(bpy.types.UIList):
    bl_idname = "GODOT_UL_scene_list"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row(align=True)
        row.prop(item, "scene_name", text="", emboss=False, icon='SCENE')
        row.prop(item, "root_node_type", text="", emboss=False)


# ---------------------------------------------------------------------------
# Hierarchy preview helper
# ---------------------------------------------------------------------------

def _draw_hierarchy_preview(layout, root_type, body_type, add_collision,
                             collision_type, sample_name="ObjectName"):
    """
    Draw a read-only monospace-style hierarchy preview showing what the
    exported .tscn node tree will look like for a typical object.
    """
    box = layout.box()
    box.label(text="Scene hierarchy preview", icon='OUTLINER')

    # Root
    box.label(text=f"{root_type}  (scene root)")

    if body_type and body_type != "NONE":
        # Body wrapper subtree
        body_row = box.row()
        body_row.label(text=f"  └─ {body_type}  \"{sample_name}\"")

        mesh_row = box.row()
        mesh_row.label(text=f"       ├─ MeshInstance3D")

        if add_collision:
            col_row = box.row()
            col_row.label(text=f"       └─ CollisionShape3D  ({collision_type})")
        else:
            mesh_only = box.row()
            mesh_only.label(text="       (no collision shape)")
    else:
        # No body — plain MeshInstance3D under root
        mesh_row = box.row()
        mesh_row.label(text=f"  └─ MeshInstance3D  \"{sample_name}\"")
        if add_collision:
            col_row = box.row()
            col_row.label(text=f"       └─ CollisionShape3D  ({collision_type})")

    # Repeat indicator
    if body_type and body_type != "NONE":
        box.label(text="  └─ … (one subtree per object)", icon='INFO')


# ---------------------------------------------------------------------------
# Fix 2, 7: Scene panel — mode picker, hierarchy preview, scoped export
# ---------------------------------------------------------------------------

class GODOT_PT_ScenePanel(Panel):
    bl_label       = "Godot Scene Export"
    bl_idname      = "GODOT_PT_scene_panel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Godot Export"
    bl_order       = 2

    def draw(self, context):
        layout = self.layout
        sp     = context.scene.godot_scene_props

        # ── Export mode picker ───────────────────────────────────────────────
        layout.separator()
        layout.label(text="Export Mode", icon='EXPORT')

        if sp.scenes and sp.active_scene_index < len(sp.scenes):
            active_scene_for_mode = sp.scenes[sp.active_scene_index]
            mode_box = layout.box()
            mode_box.prop(active_scene_for_mode, "scene_export_mode", expand=True)
            active_mode = active_scene_for_mode.scene_export_mode
        else:
            # No scenes yet — show a placeholder and default to COMBINED
            mode_box = layout.box()
            mode_box.label(
                text="Add a scene below to choose export mode.", icon='INFO'
            )
            active_mode = "COMBINED"

        # ── INDIVIDUAL FILES branch — redirect to Batch panel ─────────────
        if active_mode == "INDIVIDUAL":
            info_box = layout.box()
            info_box.label(
                text="Each object → its own .tscn  (asset library workflow)",
                icon='INFO',
            )
            info_box.label(
                text="Configure structure and export in the Batch tab below.",
            )
            info_box.operator(
                "godot_bridge.switch_to_batch",
                text="Open Batch Export Panel",
                icon='FORWARD',
            )
            return

        # ── COMBINED SCENE branch ────────────────────────────────────────────

        # Scene list
        layout.separator()
        layout.label(text="Scenes", icon='SCENE_DATA')

        row = layout.row()
        row.template_list(
            "GODOT_UL_scene_list", "",
            sp, "scenes",
            sp, "active_scene_index",
            rows=3,
        )
        col = row.column(align=True)
        col.operator("godot_bridge.add_scene",    text="", icon='ADD')
        col.operator("godot_bridge.remove_scene", text="", icon='REMOVE')

        # Active scene settings
        if sp.scenes and sp.active_scene_index < len(sp.scenes):
            active = sp.scenes[sp.active_scene_index]
            sbox = layout.box()
            sbox.label(text="Scene Settings", icon='PREFERENCES')
            sbox.prop(active, "scene_name",    text="Filename")
            sbox.prop(active, "use_object_settings", text="Use Object Settings")
            root_row = sbox.row()
            root_row.prop(active, "root_node_type", text="Root Node")
            sbox.prop(active, "root_node_name", text="Root Name")
            sbox.prop(active, "export_mode",   text="Mode")
            if not active.use_object_settings:
                sbox.prop(active, "default_body_type", text="Body")
                sbox.prop(active, "default_add_collision", text="Collision")
                if active.default_add_collision:
                    sbox.prop(active, "default_collision_type", text="Shape")

            # Live hierarchy preview
            layout.separator()
            if active.use_object_settings:
                _draw_hierarchy_preview(
                    layout,
                    root_type      = active.root_node_type,
                    body_type      = "Object setting",
                    add_collision  = True,
                    collision_type = "Object setting",
                    sample_name    = "ObjectName",
                )
            else:
                _draw_hierarchy_preview(
                    layout,
                    root_type      = active.root_node_type,
                    body_type      = active.default_body_type,
                    add_collision  = active.default_add_collision,
                    collision_type = active.default_collision_type if active.default_add_collision else "",
                    sample_name    = "ObjectName",
                )

            # Object assignment shortcuts
            layout.separator()
            assign_box = layout.box()
            assign_box.label(text="Object Assignment", icon='OBJECT_DATA')
            row2 = assign_box.row(align=True)
            op  = row2.operator("godot_bridge.assign_to_scene",
                                text="Add Selected Objects", icon='CHECKMARK')
            op.assign = True
            op2 = row2.operator("godot_bridge.assign_to_scene",
                                text="Remove Selected", icon='X')
            op2.assign = False

            # Objects assigned to this scene
            sname = active.scene_name.strip()
            assigned = []
            for o in context.scene.objects:
                if not o.godot_props.export:
                    continue
                if o.godot_props.godot_node_type == "NONE":
                    continue
                names = get_membership_names(o)
                if not names or sname in names:
                    assigned.append(o)
            lbox = assign_box.box()
            lbox.label(text=f"Object List ({len(assigned)})", icon='OBJECT_DATA')
            if assigned:
                for o in assigned[:8]:
                    lbox.label(text=o.name, icon='OBJECT_DATA')
                if len(assigned) > 8:
                    lbox.label(text=f"...and {len(assigned) - 8} more", icon='INFO')
                lbox.operator("godot_bridge.select_scene_objects",
                              text="Select Scene Objects", icon='RESTRICT_SELECT_OFF')
            else:
                lbox.label(text="No objects added yet", icon='INFO')

            # Fix 7: Export THIS scene button, scoped to the active scene
            layout.separator()
            err = validate_paths(context)
            exp_row = layout.row()
            exp_row.enabled = not bool(err)
            exp_row.scale_y = 1.3
            exp_row.operator("godot_bridge.export_active_scene",
                             text=f"Export  \"{sname}\"", icon='SCENE')

            # ── Collection Mode settings ──────────────────────────────────
            if active.export_mode == "COLLECTION":
                layout.separator()
                layout.label(text="Collection Definitions", icon='OUTLINER_COLLECTION')

                for i, cd in enumerate(active.collections):
                    cbox = layout.box()
                    header = cbox.row()
                    header.label(
                        text=cd.collection_name if cd.collection_name else "(none selected)",
                        icon='COLLECTION_COLOR_01',
                    )
                    header.operator("godot_bridge.remove_collection",
                                    text="", icon='X')

                    cbox.prop(cd, "collection_picker", text="Collection")
                    if not cd.collection_name:
                        cbox.label(text="Select a collection above.", icon='ERROR')

                    cbox.prop(cd, "body_type")
                    cbox.prop(cd, "collision_mode")

                    if cd.collision_mode == "COMBINED":
                        cbox.prop(cd, "collision_shape_type", text="Shape")
                        cbox.prop(cd, "collision_proxy", text="Proxy Mesh")
                        if cd.collision_proxy is None:
                            cbox.label(text="⚠ No proxy — collision will be skipped!", icon='ERROR')
                        else:
                            cbox.label(
                                text=f"Proxy: {cd.collision_proxy.name}  |  Shape: {cd.collision_shape_type}",
                                icon='INFO',
                            )
                        op3 = cbox.operator("godot_bridge.add_collision_proxy",
                                            text="Generate Proxy from Bounding Box",
                                            icon='MESH_CUBE')
                        op3.collection_name = cd.collection_name

                layout.operator("godot_bridge.add_collection",
                                text="Add Collection", icon='ADD')

        # ── Export ALL scenes at the bottom ──────────────────────────────────
        layout.separator()
        err = validate_paths(context)
        if err:
            for line in err.split("\n"):
                layout.label(text=line, icon='ERROR')

        row = layout.row(align=True)
        row.enabled = not bool(err)
        row.operator("godot_bridge.export_scene",
                     text="Export All Scenes", icon='FILE_TICK')


# ---------------------------------------------------------------------------
# Fix 10: Batch Export panel — hierarchy preview, asset library framing
# ---------------------------------------------------------------------------

class GODOT_PT_BatchExportPanel(Panel):
    """Panel for one-click batch export of all objects as individual .tscn files."""
    bl_label       = "Batch Object Export"
    bl_idname      = "GODOT_PT_batch_export_panel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Godot Export"
    bl_order       = 3

    def draw(self, context):
        layout = self.layout
        sp     = context.scene.godot_scene_props

        # ── Framing ─────────────────────────────────────────────────────────
        layout.label(
            text="Asset library workflow — one .tscn + .glb per object",
            icon='ASSET_MANAGER',
        )

        # Show CTA if user arrived here from the Scene panel mode picker
        if sp.hint_switch_to_batch:
            info_box = layout.box()
            info_box.label(
                text="Configure node structure below, then export.",
                icon='INFO',
            )
            info_box.label(
                text="Switch back to Scene → Combined for a single shared .tscn.",
            )

        layout.separator()

        # ── Scope ────────────────────────────────────────────────────────────
        scope_box = layout.box()
        scope_box.label(text="Scope", icon='RESTRICT_SELECT_OFF')
        scope_box.prop(sp, "batch_only_selected", text="Selected Objects Only")

        if sp.batch_only_selected:
            n = sum(1 for o in context.selected_objects if o.type == 'MESH')
            scope_box.label(text=f"{n} selected mesh object(s) will be exported", icon='INFO')
        else:
            n = sum(
                1 for o in context.scene.objects
                if o.type == 'MESH'
                and o.godot_props.export
                and not o.godot_props.is_collision_proxy
                and o.godot_props.godot_node_type != "NONE"
            )
            scope_box.label(text=f"{n} marked mesh object(s) will be exported", icon='INFO')

        # ── Per-object settings toggle ────────────────────────────────────────
        layout.separator()
        override_box = layout.box()
        override_box.label(text="Settings Source", icon='MODIFIER')
        override_box.prop(sp, "batch_use_per_object_settings",
                          text="Use Per-Object Settings (from Object panel)")
        if sp.batch_use_per_object_settings:
            override_box.label(
                text="Body / Collision read from each object's own settings.",
                icon='INFO',
            )
        else:
            override_box.label(
                text="Settings below apply to all exported objects.",
                icon='INFO',
            )

        # ── Node structure ────────────────────────────────────────────────────
        layout.separator()
        struct_box = layout.box()
        struct_box.label(text="Node structure per exported file", icon='OUTLINER')

        if not sp.batch_use_per_object_settings:
            struct_box.prop(sp, "batch_root_node_type", text="Root Node")
            struct_box.prop(sp, "batch_body_type",      text="Body Type")

            col_row = struct_box.row()
            col_row.prop(sp, "batch_add_collision", text="Add Collision Shape")
            if sp.batch_add_collision:
                struct_box.prop(sp, "batch_collision_type", text="Shape Type")

            # Live hierarchy preview using batch settings
            layout.separator()
            _draw_hierarchy_preview(
                layout,
                root_type      = sp.batch_root_node_type,
                body_type      = sp.batch_body_type,
                add_collision  = sp.batch_add_collision,
                collision_type = sp.batch_collision_type if sp.batch_add_collision else "",
                sample_name    = "ObjectName",
            )
        else:
            struct_box.label(
                text="Preview varies per object — see Object panel.",
                icon='INFO',
            )
            layout.separator()
            # Show a representative preview using the most common case
            _draw_hierarchy_preview(
                layout,
                root_type      = "Node3D",
                body_type      = "StaticBody3D",
                add_collision  = True,
                collision_type = "BOX",
                sample_name    = "ObjectName (example)",
            )

        # ── Export button ─────────────────────────────────────────────────────
        layout.separator()
        err = validate_paths_no_scenes(context)
        if err:
            for line in err.split("\n"):
                layout.label(text=line, icon='ERROR')

        row = layout.row()
        row.enabled = not bool(err) and n > 0
        row.scale_y = 1.4
        row.operator("godot_bridge.batch_export_objects",
                     text=f"Batch Export {n} Object(s)", icon='EXPORT')
