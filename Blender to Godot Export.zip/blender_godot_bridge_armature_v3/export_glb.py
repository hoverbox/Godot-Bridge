"""
export_glb.py — GLB reader and export helpers for Godot Bridge.
"""

import os
import json
import struct
import bpy
import mathutils

from .utils import sanitize


# ---------------------------------------------------------------------------
# GLB reader  (pure Python stdlib — no external deps)
# ---------------------------------------------------------------------------

def read_glb_json(filepath: str) -> dict:
    try:
        with open(filepath, 'rb') as f:
            if f.read(4) != b'glTF':
                return {}
            f.read(8)
            chunk_len  = struct.unpack_from('<I', f.read(4))[0]
            chunk_type = struct.unpack_from('<I', f.read(4))[0]
            if chunk_type != 0x4E4F534A:   # "JSON"
                return {}
            return json.loads(f.read(chunk_len))
    except Exception:
        return {}


def glb_node_transforms(glb_json: dict) -> dict:
    result = {}
    for node in glb_json.get("nodes", []):
        name = node.get("name", "")
        t = tuple(node.get("translation", [0.0, 0.0, 0.0]))
        r = tuple(node.get("rotation",    [0.0, 0.0, 0.0, 1.0]))
        s = tuple(node.get("scale",       [1.0, 1.0, 1.0]))
        result[name] = (t, r, s)
    return result



def related_armatures_for_mesh(obj) -> list:
    """Return unique ARMATURE objects that may drive a mesh.

    Uses Blender's native find_armature() first, then checks direct parents
    and Armature modifiers as fallbacks.  Keeping this logic centralized makes
    every GLB export path rig-safe by default.
    """
    if obj is None or obj.type != 'MESH':
        return []

    candidates = []

    try:
        arm = obj.find_armature()
    except Exception:
        arm = None
    if arm and arm.type == 'ARMATURE':
        candidates.append(arm)

    if obj.parent and obj.parent.type == 'ARMATURE':
        candidates.append(obj.parent)

    for mod in obj.modifiers:
        if mod.type == 'ARMATURE' and mod.object and mod.object.type == 'ARMATURE':
            candidates.append(mod.object)

    out = []
    seen = set()
    for arm in candidates:
        if arm.name not in seen:
            seen.add(arm.name)
            out.append(arm)
    return out


def object_has_armature(obj) -> bool:
    """True when obj is a mesh driven by an armature."""
    return bool(related_armatures_for_mesh(obj))

# ---------------------------------------------------------------------------
# GLB export  — completely isolated, cannot corrupt other exports
# ---------------------------------------------------------------------------

def export_glb_isolated(context, objects, filepath: str, apply_transforms: bool, strip_materials: bool = False) -> bool:
    """
    Export mesh objects plus any related armatures to a GLB file.

    Rig safety is enforced here, not at call sites: whenever a mesh is driven
    by an armature, export_apply is forced off so the exporter does not bake
    transforms into skinned geometry.  This protects scene export, batch export,
    temporary transform probes, and any future callers equally.

    Selection, active object, and hide flags are restored before returning.
    Returns True on success, False if there were no mesh objects to export.
    """
    mesh_objects = [o for o in objects if o.type == 'MESH']
    if not mesh_objects:
        return False

    armature_objects = []
    seen_arms = set()
    for obj in mesh_objects:
        for arm in related_armatures_for_mesh(obj):
            if arm.name not in seen_arms:
                seen_arms.add(arm.name)
                armature_objects.append(arm)

    export_objects = mesh_objects + armature_objects

    prev_selected = list(context.selected_objects)
    prev_active = context.view_layer.objects.active
    prev_hide_vp  = {o.name: o.hide_viewport for o in export_objects}
    prev_hide_rnd = {o.name: o.hide_render   for o in export_objects}

    has_armature = bool(armature_objects)
    effective_apply = apply_transforms and not has_armature

    try:
        for obj in export_objects:
            obj.hide_viewport = False
            obj.hide_render   = False

        bpy.ops.object.select_all(action='DESELECT')
        for obj in export_objects:
            obj.select_set(True)
        context.view_layer.objects.active = mesh_objects[0]

        gltf_kwargs = dict(
            filepath=filepath,
            export_format='GLB',
            use_selection=True,
            export_yup=True,
            export_apply=effective_apply,
            export_cameras=False,
            export_lights=False,
            export_skins=has_armature,
            export_animations=has_armature,
        )
        if strip_materials:
            gltf_kwargs['export_image_format'] = 'NONE'
            gltf_kwargs['export_materials'] = 'NONE'
        bpy.ops.export_scene.gltf(**gltf_kwargs)
        return True

    finally:
        for obj in export_objects:
            obj.hide_viewport = prev_hide_vp[obj.name]
            obj.hide_render   = prev_hide_rnd[obj.name]

        bpy.ops.object.select_all(action='DESELECT')
        for obj in prev_selected:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
        if prev_active and prev_active.name in bpy.data.objects:
            context.view_layer.objects.active = prev_active


def export_concave_glb(context, obj, glb_path: str, origin_godot=None) -> bool:
    """Export a single mesh as a -colonly GLB for ConcavePolygonShape3D import.

    origin_godot optionally recenters the exported collision geometry around a
    body/mesh origin already written into the TSCN transform.  This keeps
    concave/trimesh collision from being double-offset when normal meshes are
    exported centered.
    """
    original_name  = obj.name
    prev_hide_vp   = obj.hide_viewport
    prev_hide_rnd  = obj.hide_render
    prev_location  = obj.location.copy()

    try:
        obj.name          = sanitize(obj.name) + "-colonly"
        obj.hide_viewport = False
        obj.hide_render   = False
        if origin_godot is not None:
            # Godot (x,y,z) maps back to Blender (x,-z,y).
            origin_blender = mathutils.Vector((origin_godot.x, -origin_godot.z, origin_godot.y))
            obj.location = obj.location - origin_blender

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        bpy.ops.export_scene.gltf(
            filepath=glb_path,
            export_format='GLB',
            use_selection=True,
            export_yup=True,
            export_apply=True,
            export_cameras=False,
            export_lights=False,
        )
        return True

    finally:
        obj.name          = original_name
        obj.hide_viewport = prev_hide_vp
        obj.hide_render   = prev_hide_rnd
        obj.location      = prev_location
        bpy.ops.object.select_all(action='DESELECT')


def write_concave_import_file(glb_path: str, res_path: str) -> None:
    """
    Write a Godot .import sidecar file next to glb_path that enables
    node name suffix processing so Godot recognises the -colonly suffix
    and generates a ConcavePolygonShape3D on import.
    res_path is the res:// path of the GLB (e.g. res://Assets/Level_1/foo-colonly.glb).
    """
    import_path = glb_path + ".import"

    content = (
        "[remap]\n\n"
        "importer=\"scene\"\n"
        "importer_version=1\n"
        "type=\"PackedScene\"\n\n"
        "[deps]\n\n"
        f"source_file=\"{res_path}\"\n\n"
        "[params]\n\n"
        "nodes/root_type=\"\"\n"
        "nodes/root_name=\"\"\n"
        "nodes/apply_root_scale=true\n"
        "nodes/root_scale=1.0\n"
        "nodes/import_as_skeleton_bones=false\n"
        "nodes/use_name_suffixes=true\n"
        "nodes/use_node_type_suffixes=true\n"
        "meshes/ensure_tangents=true\n"
        "meshes/generate_lods=false\n"
        "meshes/create_shadow_meshes=false\n"
        "meshes/light_baking=0\n"
        "meshes/force_disable_compression=false\n"
        "skins/use_named_skins=true\n"
        "animation/import=false\n"
        "_subresources={}\n"
    )

    with open(import_path, 'w') as f:
        f.write(content)

def write_glb_import_file(glb_path: str, res_path: str,
                           material_overrides: dict | None = None,
                           import_animations: bool = False) -> None:
    """
    Write a Godot .import sidecar for a mesh GLB.

    material_overrides: dict mapping surface index (int) to the res:// path
        of a .tres file, e.g. {0: "res://assets/MyMat.tres"}.
        These are written into _subresources so Godot applies them to every
        MeshInstance inside the imported PackedScene — the only way to override
        materials on an instanced scene from outside it.

    The mesh path key inside _subresources uses the wildcard form
        "PATH_TO_MESH_IN_SCENE/MESH_NAME"
    Godot matches any mesh in the scene whose path ends with that suffix.
    We use the GLB filename stem (without extension) as both the node and
    mesh name, which matches what Blender's GLTF exporter produces.
    """
    import_path = glb_path + ".import"

    # Build _subresources value.
    # Godot ConfigFile format for mesh material overrides (as written by the editor):
    #   _subresources={"meshes": {"MeshName": {"material/0": "res://path.tres"}}}
    # The key is the mesh data-block name (GLB stem). Value is a plain res:// string.
    if material_overrides:
        glb_stem = os.path.splitext(os.path.basename(glb_path))[0]
        mat_entries = ", ".join(
            f'"material/{i}": "{p}"'
            for i, p in sorted(material_overrides.items())
        )
        subresources = '{' + '"meshes": {"' + glb_stem + '": {' + mat_entries + '}}' + '}'
    else:
        subresources = "{}"

    lines = [
        "[remap]",
        "",
        'importer="scene"',
        "importer_version=1",
        'type="PackedScene"',
        "",
        "[deps]",
        "",
        f'source_file="{res_path}"',
        "",
        "[params]",
        "",
        'nodes/root_type=""',
        'nodes/root_name=""',
        "nodes/apply_root_scale=true",
        "nodes/root_scale=1.0",
        "nodes/import_as_skeleton_bones=false",
        "nodes/use_name_suffixes=false",
        "nodes/use_node_type_suffixes=false",
        "meshes/ensure_tangents=true",
        "meshes/generate_lods=false",
        "meshes/create_shadow_meshes=false",
        "meshes/light_baking=0",
        "meshes/force_disable_compression=false",
        "skins/use_named_skins=true",
        f"animation/import={'true' if import_animations else 'false'}",
        f"_subresources={subresources}",
    ]

    with open(import_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines) + "\n")
