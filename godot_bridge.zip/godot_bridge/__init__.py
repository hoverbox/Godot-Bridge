bl_info = {
    "name": "Godot Bridge",
    "author": "Godot Bridge",
    "version": (2, 0, 0),
    "blender": (3, 6, 0),
    "location": "Properties > Object > Godot Bridge  |  Properties > Scene > Godot Bridge",
    "description": "Tag Blender objects with Godot 4 node types and export the whole scene as a single .tscn",
    "category": "Import-Export",
}

import bpy
from . import properties, panels, operators


def register():
    properties.register()
    operators.register()
    panels.register()


def unregister():
    panels.unregister()
    operators.unregister()
    properties.unregister()
