import bpy
from bpy.types import Panel


class GODOT_PT_ObjectPanel(Panel):
    bl_label       = "Godot Bridge"
    bl_space_type  = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context     = "object"
    bl_options     = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def draw_header(self, context):
        self.layout.prop(context.object.godot_props, "enabled", text="")

    def draw(self, context):
        layout = self.layout
        props  = context.object.godot_props

        layout.enabled = props.enabled

        # ── Node type ────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Node Type", icon="SCENE_DATA")
        box.prop(props, "godot_type", text="")

        # ── Collision shape options ──────────────────────────────────────
        if props.godot_type == "CollisionShape3D":
            box = layout.box()
            box.label(text="Collision Shape", icon="MESH_ICOSPHERE")
            box.prop(props, "collision_shape", text="")

            col = box.column(align=True)
            col.scale_y = 0.8
            if props.collision_shape == "TRIMESH":
                col.label(text="Trimesh: use with StaticBody3D or Area3D only.", icon="INFO")
            elif props.collision_shape == "CONVEX":
                col.label(text="Convex Hull: works with all body types.", icon="INFO")

            # Remind the user their mesh will be hidden from render
            box.separator()
            col = box.column()
            col.scale_y = 0.8
            col.label(text="This mesh will be hidden from render", icon="HIDE_ON")
            col.label(text="on export so it won't appear in Godot.", icon="BLANK1")


class GODOT_PT_ScenePanel(Panel):
    bl_label       = "Godot Bridge"
    bl_space_type  = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context     = "scene"
    bl_options     = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout      = self.layout
        scene_props = context.scene.godot_scene

        # ── Project settings ─────────────────────────────────────────────
        box = layout.box()
        box.label(text="Project Settings", icon="SETTINGS")
        box.prop(scene_props, "godot_project_path")
        box.prop(scene_props, "export_path")
        box.prop(scene_props, "scene_name")

        # ── Scene root node type ─────────────────────────────────────────
        box = layout.box()
        box.label(text="Scene Root", icon="SCENE_DATA")
        box.prop(scene_props, "root_node_type", text="Root Node Type")

        layout.separator()

        # ── Tagged object overview ────────────────────────────────────────
        tagged = [
            o for o in context.scene.objects
            if o.godot_props.enabled and o.godot_props.godot_type != "NONE"
        ]
        box = layout.box()
        box.label(text=f"Tagged Objects: {len(tagged)}", icon="OUTLINER_OB_EMPTY")

        if tagged:
            col = box.column(align=True)
            col.scale_y = 0.85
            for obj in tagged:
                row = col.row(align=True)
                row.label(text=obj.name, icon="OBJECT_DATA")
                row.label(text=obj.godot_props.godot_type)
                if obj.godot_props.godot_type == "CollisionShape3D":
                    row.label(text=f"[{obj.godot_props.collision_shape}]")

        layout.separator()

        # ── Export button ────────────────────────────────────────────────
        row = layout.row()
        row.scale_y = 2.0
        row.operator("godot_bridge.export_scene", icon="EXPORT", text="Export Scene .tscn")


classes = (
    GODOT_PT_ObjectPanel,
    GODOT_PT_ScenePanel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
