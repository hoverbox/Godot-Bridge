import bpy
from bpy.props import (
    BoolProperty, EnumProperty, PointerProperty, StringProperty
)
from bpy.types import PropertyGroup


# ---------------------------------------------------------------------------
# Choices
# ---------------------------------------------------------------------------

GODOT_NODE_TYPES = [
    ("NONE",                "(No Override)",         "Do not export this object"),
    ("Node3D",              "Node3D",                "Plain transform node"),
    ("MeshInstance3D",      "MeshInstance3D",        "Visible mesh"),
    ("StaticBody3D",        "StaticBody3D",          "Immovable physics body"),
    ("AnimatableBody3D",    "AnimatableBody3D",      "Animated physics body"),
    ("RigidBody3D",         "RigidBody3D",           "Simulated physics body"),
    ("CharacterBody3D",     "CharacterBody3D",       "Kinematic character body"),
    ("Area3D",              "Area3D",                "Trigger / detection volume"),
    ("CollisionShape3D",    "CollisionShape3D",      "Collision shape (invisible in Godot)"),
    ("VehicleBody3D",       "VehicleBody3D",         "Vehicle physics body"),
    ("VehicleWheel3D",      "VehicleWheel3D",        "Vehicle wheel"),
    ("Marker3D",            "Marker3D",              "Empty transform marker"),
    ("OmniLight3D",         "OmniLight3D",           "Omni light"),
    ("SpotLight3D",         "SpotLight3D",           "Spot light"),
    ("DirectionalLight3D",  "DirectionalLight3D",    "Directional / sun light"),
    ("Camera3D",            "Camera3D",              "Camera"),
    ("AudioStreamPlayer3D", "AudioStreamPlayer3D",   "3D audio emitter"),
    ("NavigationRegion3D",  "NavigationRegion3D",    "Navigation mesh region"),
    ("GPUParticles3D",      "GPUParticles3D",        "GPU particles"),
    ("CPUParticles3D",      "CPUParticles3D",        "CPU particles"),
    ("Path3D",              "Path3D",                "Spline path"),
    ("SpringArm3D",         "SpringArm3D",           "Camera spring arm"),
    ("BoneAttachment3D",    "BoneAttachment3D",      "Skeleton bone attachment"),
    ("Decal",               "Decal",                 "Projected decal"),
    ("OccluderInstance3D",  "OccluderInstance3D",    "Occlusion occluder"),
    ("FogVolume",           "FogVolume",             "Volumetric fog region"),
    ("WorldEnvironment",    "WorldEnvironment",      "Global environment"),
    ("ReflectionProbe",     "ReflectionProbe",       "Reflection probe"),
    ("LightmapGI",          "LightmapGI",            "Lightmap GI"),
    ("VoxelGI",             "VoxelGI",               "Voxel GI"),
    ("MultiMeshInstance3D", "MultiMeshInstance3D",   "Multi-mesh renderer"),
    ("GridMap",             "GridMap",               "Grid-based tile map"),
]

# Body types that can act as a scene root with children underneath
ROOT_NODE_TYPES = [
    ("Node3D",           "Node3D",           "Plain root node"),
    ("StaticBody3D",     "StaticBody3D",     "Immovable physics body"),
    ("AnimatableBody3D", "AnimatableBody3D", "Animated physics body"),
    ("RigidBody3D",      "RigidBody3D",      "Simulated physics body"),
    ("CharacterBody3D",  "CharacterBody3D",  "Kinematic character body"),
    ("Area3D",           "Area3D",           "Trigger / detection volume"),
    ("VehicleBody3D",    "VehicleBody3D",    "Vehicle physics body"),
]

COLLISION_SHAPE_TYPES = [
    ("TRIMESH", "Trimesh (ConcavePolygon)",   "Exact triangle mesh — best for static terrain/walls"),
    ("CONVEX",  "Convex Hull (ConvexPolygon)","Convex hull — works with all body types"),
    ("BOX",     "Box",                        "Axis-aligned box from bounding box"),
    ("SPHERE",  "Sphere",                     "Sphere from bounding box"),
    ("CAPSULE", "Capsule",                    "Capsule from bounding box"),
    ("CYLINDER","Cylinder",                   "Cylinder from bounding box"),
]


# ---------------------------------------------------------------------------
# Per-object properties
# ---------------------------------------------------------------------------

class GodotObjectProperties(PropertyGroup):

    enabled: BoolProperty(
        name="Tag for Godot Export",
        description="Include this object in the Godot scene export",
        default=False,
    )

    godot_type: EnumProperty(
        name="Godot Node Type",
        description="The Godot node type this object will become in the exported .tscn",
        items=GODOT_NODE_TYPES,
        default="NONE",
    )

    # Only shown when godot_type == "CollisionShape3D"
    collision_shape: EnumProperty(
        name="Shape Type",
        description="How to generate the collision shape from this mesh",
        items=COLLISION_SHAPE_TYPES,
        default="TRIMESH",
    )


# ---------------------------------------------------------------------------
# Scene-level settings
# ---------------------------------------------------------------------------

class GodotSceneProperties(PropertyGroup):

    godot_project_path: StringProperty(
        name="Godot Project Path",
        description="Absolute path to the folder containing your project.godot file",
        subtype="DIR_PATH",
        default="",
    )

    export_path: StringProperty(
        name="Export Path (inside project)",
        description="Relative path inside the project where the .tscn will be written, e.g. scenes/level",
        default="scenes",
    )

    scene_name: StringProperty(
        name="Scene File Name",
        description="Name for the exported .tscn file (without extension)",
        default="ExportedScene",
    )

    root_node_type: EnumProperty(
        name="Scene Root Node Type",
        description="The Godot node type for the root node of the exported scene",
        items=ROOT_NODE_TYPES,
        default="Node3D",
    )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    GodotObjectProperties,
    GodotSceneProperties,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.godot_props = PointerProperty(type=GodotObjectProperties)
    bpy.types.Scene.godot_scene  = PointerProperty(type=GodotSceneProperties)


def unregister():
    del bpy.types.Object.godot_props
    del bpy.types.Scene.godot_scene
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
