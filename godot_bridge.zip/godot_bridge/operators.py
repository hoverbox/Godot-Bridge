import bpy
import os
import math
import bmesh
import mathutils
from bpy.types import Operator


# ---------------------------------------------------------------------------
# .tscn writer
# ---------------------------------------------------------------------------

class TscnWriter:
    def __init__(self):
        self._ext_resources = []
        self._sub_resources = []
        self._nodes         = []
        self._next_ext_id   = 1
        self._next_sub_id   = 1

    def add_ext_resource(self, res_type: str, path: str) -> str:
        # Reuse if already registered
        for rt, p, rid in self._ext_resources:
            if p == path:
                return rid
        rid = str(self._next_ext_id)
        self._ext_resources.append((res_type, path, rid))
        self._next_ext_id += 1
        return rid

    def add_sub_resource(self, res_type: str, props: str) -> str:
        rid = str(self._next_sub_id)
        self._sub_resources.append((res_type, rid, props))
        self._next_sub_id += 1
        return rid

    def add_node(self, name: str, node_type: str, parent: str = None,
                 props: str = "", instance_rid: str = None):
        parts = [f'[node name="{name}" type="{node_type}"']
        if parent is not None:
            parts.append(f'parent="{parent}"')
        if instance_rid is not None:
            parts.append(f'instance=ExtResource("{instance_rid}")')
        header = " ".join(parts) + "]"
        block  = header + ("\n" + props.strip() if props.strip() else "")
        self._nodes.append(block)

    def serialize(self) -> str:
        load_steps = 1 + len(self._ext_resources) + len(self._sub_resources)
        lines = [f"[gd_scene load_steps={load_steps} format=3]\n"]
        for res_type, path, rid in self._ext_resources:
            lines.append(f'[ext_resource type="{res_type}" path="{path}" id="{rid}"]')
        if self._ext_resources:
            lines.append("")
        for res_type, rid, props in self._sub_resources:
            lines.append(f'[sub_resource type="{res_type}" id="{rid}"]')
            if props.strip():
                lines.append(props.strip())
            lines.append("")
        for node_block in self._nodes:
            lines.append(node_block)
            lines.append("")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Float / vector formatting
# ---------------------------------------------------------------------------

def _f(value: float) -> str:
    if not math.isfinite(value):
        return "0.0"
    if abs(value) < 1e-6:
        return "0.0"
    s = f"{value:.6f}".rstrip("0")
    if s.endswith("."):
        s += "0"
    return s

def _flat_vec3(x, y, z) -> str:
    return f"{_f(x)}, {_f(y)}, {_f(z)}"

def _vec3_prop(x, y, z) -> str:
    return f"Vector3({_f(x)}, {_f(y)}, {_f(z)})"

def _blender_to_godot_transform(matrix) -> str:
    bx = matrix.col[0].to_3d()
    by = matrix.col[1].to_3d()
    bz = matrix.col[2].to_3d()
    bt = matrix.col[3].to_3d()
    gx = ( bx.x,  bx.z, -bx.y)
    gy = ( by.x,  by.z, -by.y)
    gz = ( bz.x,  bz.z, -bz.y)
    gt = ( bt.x,  bt.z, -bt.y)
    vals = list(gx) + list(gy) + list(gz) + list(gt)
    return f"Transform3D({', '.join(_f(v) for v in vals)})"


# ---------------------------------------------------------------------------
# Mesh helpers
# ---------------------------------------------------------------------------

def _triangulate_mesh(obj):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj  = obj.evaluated_get(depsgraph)
    mesh      = eval_obj.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    world = obj.matrix_world
    tris  = [tuple(world @ v.co.copy() for v in face.verts) for face in bm.faces]
    bm.free()
    eval_obj.to_mesh_clear()
    return tris

def _get_bounding_box(obj):
    world   = obj.matrix_world
    corners = [world @ mathutils.Vector(c) for c in obj.bound_box]
    min_v = mathutils.Vector((min(c.x for c in corners), min(c.y for c in corners), min(c.z for c in corners)))
    max_v = mathutils.Vector((max(c.x for c in corners), max(c.y for c in corners), max(c.z for c in corners)))
    return (min_v + max_v) / 2, max_v - min_v


# ---------------------------------------------------------------------------
# Shape builders
# ---------------------------------------------------------------------------

def _build_trimesh_shape(obj, writer):
    tris = _triangulate_mesh(obj)
    if not tris:
        return None
    flat = []
    for tri in tris:
        for v in tri:
            flat.append(_flat_vec3(v.x, v.z, -v.y))
    return writer.add_sub_resource("ConcavePolygonShape3D",
        f"data = PackedVector3Array({', '.join(flat)})")

def _build_convex_shape(obj, writer):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj  = obj.evaluated_get(depsgraph)
    mesh      = eval_obj.to_mesh()
    world     = obj.matrix_world
    unique    = list({tuple((world @ v.co).freeze()) for v in mesh.vertices})
    eval_obj.to_mesh_clear()
    flat = [_flat_vec3(v[0], v[2], -v[1]) for v in unique]
    return writer.add_sub_resource("ConvexPolygonShape3D",
        f"points = PackedVector3Array({', '.join(flat)})")

def _build_box_shape(obj, writer):
    _, size = _get_bounding_box(obj)
    return writer.add_sub_resource("BoxShape3D",
        f"size = {_vec3_prop(size.x, size.z, size.y)}")

def _build_sphere_shape(obj, writer):
    _, size = _get_bounding_box(obj)
    return writer.add_sub_resource("SphereShape3D",
        f"radius = {_f(max(size.x, size.y, size.z) / 2)}")

def _build_capsule_shape(obj, writer):
    _, size = _get_bounding_box(obj)
    return writer.add_sub_resource("CapsuleShape3D",
        f"radius = {_f(max(size.x, size.y) / 2)}\nheight = {_f(size.z)}")

def _build_cylinder_shape(obj, writer):
    _, size = _get_bounding_box(obj)
    return writer.add_sub_resource("CylinderShape3D",
        f"radius = {_f(max(size.x, size.y) / 2)}\nheight = {_f(size.z)}")

SHAPE_BUILDERS = {
    "TRIMESH":  _build_trimesh_shape,
    "CONVEX":   _build_convex_shape,
    "BOX":      _build_box_shape,
    "SPHERE":   _build_sphere_shape,
    "CAPSULE":  _build_capsule_shape,
    "CYLINDER": _build_cylinder_shape,
}


# ---------------------------------------------------------------------------
# GLB export — one .glb per MeshInstance3D object
# ---------------------------------------------------------------------------

def _export_single_glb(obj, glb_path: str, errors: list) -> bool:
    """Export one object to its own .glb. Returns True on success."""
    originally_selected = list(bpy.context.selected_objects)
    originally_active   = bpy.context.view_layer.objects.active

    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

    try:
        bpy.ops.export_scene.gltf(
            filepath         = glb_path,
            export_format    = 'GLB',
            use_selection    = True,
            export_apply     = True,
            export_yup       = True,
            export_texcoords = True,
            export_normals   = True,
            export_materials = 'EXPORT',
        )
        success = True
    except Exception as e:
        errors.append(f"GLB export failed for '{obj.name}': {e}")
        success = False

    bpy.ops.object.select_all(action='DESELECT')
    for o in originally_selected:
        o.select_set(True)
    bpy.context.view_layer.objects.active = originally_active
    return success


# ---------------------------------------------------------------------------
# Scene tree helpers
# ---------------------------------------------------------------------------

def _collect_export_objects(scene):
    tagged = [
        o for o in scene.objects
        if o.godot_props.enabled and o.godot_props.godot_type != "NONE"
    ]
    ordered = []
    visited = set()

    def visit(obj):
        if obj in visited:
            return
        visited.add(obj)
        if obj.parent and obj.parent in tagged:
            visit(obj.parent)
        ordered.append(obj)

    for obj in tagged:
        visit(obj)
    return ordered


def _godot_parent_path(obj, exported_names: dict) -> str:
    if obj.parent is None or obj.parent not in exported_names:
        return "."
    parts = []
    current = obj.parent
    while current is not None and current in exported_names:
        parts.append(exported_names[current])
        current = current.parent
    parts.reverse()
    return "/".join(parts)


# ---------------------------------------------------------------------------
# Export operator
# ---------------------------------------------------------------------------

class GODOT_OT_ExportScene(Operator):
    bl_idname      = "godot_bridge.export_scene"
    bl_label       = "Export Scene .tscn"
    bl_description = (
        "Export tagged objects as a Godot 4 .tscn. "
        "Each MeshInstance3D gets its own .glb. "
        "Collision shapes are baked as shape data directly into the .tscn."
    )

    def execute(self, context):
        scene_props = context.scene.godot_scene

        # ── Validate ─────────────────────────────────────────────────────
        project_path = bpy.path.abspath(scene_props.godot_project_path).strip()
        if not project_path or not os.path.isdir(project_path):
            self.report({"ERROR"}, "Godot Project Path is not set or does not exist.")
            return {"CANCELLED"}

        # ── Paths ────────────────────────────────────────────────────────
        rel_export = scene_props.export_path.strip().strip("/\\")
        export_dir = os.path.join(project_path, rel_export)
        os.makedirs(export_dir, exist_ok=True)

        scene_name = scene_props.scene_name.strip() or "ExportedScene"
        tscn_path  = os.path.join(export_dir, f"{scene_name}.tscn")

        # ── Gather objects ───────────────────────────────────────────────
        objects = _collect_export_objects(context.scene)
        if not objects:
            self.report({"WARNING"}, "No objects are tagged for export.")
            return {"CANCELLED"}

        print(f"[Godot Bridge] Exporting {len(objects)} object(s):")
        for o in objects:
            print(f"  {o.name}  →  {o.godot_props.godot_type}")

        errors  = []
        writer  = TscnWriter()
        exported_names: dict = {}

        # Scene root
        writer.add_node(scene_name, scene_props.root_node_type)

        for obj in objects:
            gtype     = obj.godot_props.godot_type
            node_name = obj.name
            exported_names[obj] = node_name

            parent_path = (
                _godot_parent_path(obj, exported_names)
                if obj.parent and obj.parent in exported_names
                else "."
            )

            transform = _blender_to_godot_transform(obj.matrix_world)

            # ── MeshInstance3D ───────────────────────────────────────────
            # Export this object to its own .glb and instance it as a
            # Node3D subscene. Godot renders the mesh from the .glb.
            if gtype == "MeshInstance3D":
                glb_name = f"{obj.name}.glb"
                glb_path = os.path.join(export_dir, glb_name)
                glb_res  = f"res://{rel_export}/{glb_name}".replace("\\", "/")

                ok = _export_single_glb(obj, glb_path, errors)
                if ok:
                    rid = writer.add_ext_resource("PackedScene", glb_res)
                    # Instance the .glb as a Node3D child — this is the correct
                    # way to embed a .glb in a .tscn in Godot 4.
                    # The node type must be Node3D (not MeshInstance3D) because
                    # a .glb is a full PackedScene, not a bare mesh resource.
                    writer.add_node(
                        node_name, "Node3D",
                        parent=parent_path,
                        props=f"transform = {transform}",
                        instance_rid=rid,
                    )
                    print(f"[Godot Bridge]   ✓ {glb_name}")
                else:
                    print(f"[Godot Bridge]   ✗ {obj.name} GLB export failed")

            # ── CollisionShape3D ─────────────────────────────────────────
            elif gtype == "CollisionShape3D":
                if obj.type != "MESH":
                    errors.append(f"'{obj.name}' tagged CollisionShape3D but has no mesh — skipped.")
                    continue

                builder  = SHAPE_BUILDERS.get(obj.godot_props.collision_shape)
                shape_id = builder(obj, writer) if builder else None

                if shape_id is None:
                    errors.append(f"'{obj.name}': failed to build shape — skipped.")
                    continue

                writer.add_node(
                    node_name, "CollisionShape3D",
                    parent=parent_path,
                    props=f"transform = {transform}\nshape = SubResource(\"{shape_id}\")",
                )
                print(f"[Godot Bridge]   ✓ {obj.name} collision shape baked")

            # ── All other node types ─────────────────────────────────────
            else:
                writer.add_node(node_name, gtype,
                                parent=parent_path,
                                props=f"transform = {transform}")
                print(f"[Godot Bridge]   ✓ {obj.name} as {gtype}")

        # ── Write .tscn ──────────────────────────────────────────────────
        tscn_content = writer.serialize()
        with open(tscn_path, "w", encoding="utf-8") as f:
            f.write(tscn_content)

        print(f"[Godot Bridge] Written: {tscn_path}")

        msg = f"Exported to {export_dir}"
        if errors:
            for e in errors:
                print(f"[Godot Bridge] WARNING: {e}")
            msg += f"  ({len(errors)} warning(s) — see console)"

        self.report({"INFO"}, msg)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (GODOT_OT_ExportScene,)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
